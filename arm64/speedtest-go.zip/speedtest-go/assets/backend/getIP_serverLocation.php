<?php

$serverLoc = '22.3302,114.1595';
